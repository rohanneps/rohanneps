from setuptools import setup
 
setup(
    name = 'gbd',
    packages = ['gbd'],
    version = '0.0.1',
    url='https://github.com/rohanneps/rohanneps/tree/master/Scrapper_Test/gbd',
    description = 'Test module',
    author='Rohan Amatya',
    keywords='sample setuptools development',
    author_email='rohanneps@gmail.com',
)