

def add(a,b):
	print "SUM is"
	return a+b

