from setuptools import setup,find_packages
 
setup(
    name = 'gbdqa',
    packages = find_packages(),
    version = '0.1.0',
    description = 'Get even or odd',
    author='Rohan Amatya',
    keywords='Even Odd',
    author_email='rohanneps@gmail.com',
)