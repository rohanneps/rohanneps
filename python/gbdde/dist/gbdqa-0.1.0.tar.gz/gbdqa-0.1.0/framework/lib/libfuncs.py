
def get_datatype(data):
	return type(data)

def get_reverse(var):
	return var[::-1]